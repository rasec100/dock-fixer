#!/bin/bash
killall Dock
